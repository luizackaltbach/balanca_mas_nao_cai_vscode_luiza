<?php
include_once "sessao.php";
include_once "conexao.php";

$conn = @mysqli_connect($localhost, $user, $password, $banco);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $descricao = isset($_POST['Descricao']) ? trim($_POST['Descricao']) : '';
    $dtInicio = isset($_POST['dtInicio']) ? trim($_POST['dtInicio']) : '';
    $dtFim = isset($_POST['dtFim']) ? trim($_POST['dtFim']) : '';
    $idEngenheiro = isset($_POST['idEngenheiro']) ? trim($_POST['idEngenheiro']) : '';

    if (!$conn) {
        echo "<script>alert('Erro de conexão com o banco: " . addslashes(mysqli_connect_error()) . "');</script>";
    } elseif (!empty($descricao) && !empty($dtInicio) && !empty($idEngenheiro)) {
        $descTratada = mysqli_real_escape_string($conn, $descricao);
        $dtIniTratada = mysqli_real_escape_string($conn, $dtInicio);
        $dtFimTratada = !empty($dtFim) ? "'" . mysqli_real_escape_string($conn, $dtFim) . "'" : "NULL";
        $idEngTratado = mysqli_real_escape_string($conn, $idEngenheiro);

        // Busca CREA e Data de Admissão do engenheiro selecionado
        $nrCrea = "";
        $dtAdmissaoEng = "";
        $resEng = mysqli_query($conn, "SELECT nrCREA, dtAdmissao FROM engenheiros WHERE idEngenheiro = '$idEngTratado'");
        if ($resEng && $rowEng = mysqli_fetch_assoc($resEng)) {
            $nrCrea = mysqli_real_escape_string($conn, $rowEng['nrCREA']);
            $dtAdmissaoEng = mysqli_real_escape_string($conn, $rowEng['dtAdmissao']);
        }

        $sql = "INSERT INTO obras (Descricao, dtInicio, dtFim, idEngenheiro, nrCrea, dtDdmissaoEngenheiro) 
                VALUES ('$descTratada', '$dtIniTratada', $dtFimTratada, '$idEngTratado', '$nrCrea', '$dtAdmissaoEng')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>
                    alert('Obra cadastrada com sucesso!');
                    window.location.href = 'obras.php';
                  </script>";
            exit;
        } else {
            $erro = mysqli_error($conn);
            echo "<script>
                    alert('Erro ao incluir: " . addslashes($erro) . "');
                  </script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Inclusão de Obra</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
            padding-top: 100px;
        }

        ul.menu-topo {
            list-style-type: none;
            margin: 0;
            padding: 0 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #ffffff;
            border-bottom: 4px solid #e67e22;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            box-sizing: border-box;
            z-index: 1000;
        }

        ul.menu-topo li {
            display: inline-block;
        }

        ul.menu-topo li a {
            display: block;
            padding: 16px 20px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            font-size: 0.95rem;
            transition: all 0.2s ease;
        }

        ul.menu-topo li a:hover {
            background-color: #fdf2e9;
            color: #d35400;
        }

        ul.menu-topo li:last-child {
            margin-left: auto;
        }

        ul.menu-topo li a[href="logout.php"] {
            color: #c0392b;
        }

        ul.menu-topo li a[href="logout.php"]:hover {
            background-color: #c0392b;
            color: #ffffff;
        }

        h2 {
            color: #d35400;
            margin-top: 20px;
            font-size: 1.8rem;
        }

        form {
            margin-top: 20px;
            background: #ffffff;
            padding: 25px;
            border-radius: 10px;
            border-top: 5px solid #e67e22;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            max-width: 500px;
            width: 90%;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
        }

        td {
            padding: 4px 0;
            vertical-align: middle;
        }

        td:first-child {
            text-align: right;
            padding-right: 12px;
            width: 38%;
        }

        label {
            font-size: 0.9rem;
            font-weight: bold;
            color: #555555;
        }

        input[type="text"], input[type="date"], select {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 0.9rem;
            box-sizing: border-box;
            background-color: #fff;
        }

        input[type="text"]:focus, input[type="date"]:focus, select:focus {
            border-color: #e67e22;
            outline: none;
        }

        .acoes {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-acao {
            background-color: #e67e22;
            color: #ffffff;
            border: none;
            padding: 10px 16px;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            display: inline-block;
            transition: background-color 0.2s ease;
        }

        .btn-acao:hover {
            background-color: #d35400;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 18px;
            color: #888888;
            font-size: 0.88rem;
            text-decoration: underline;
            font-weight: bold;
            transition: color 0.2s ease;
        }

        .btn-voltar:hover {
            color: #555555;
        }
    </style>
</head>
<body>

    <ul class="menu-topo">
        <li><a href="funcoes.php">Funções</a></li>
        <li><a href="engenheiros.php">Engenheiros envolvidos</a></li>
        <li><a href="fase.php">Fase da obra</a></li>
        <li><a href="obras.php">Obras</a></li>
        <?php if (isset($_SESSION['flStatus']) && $_SESSION['flStatus'] == 1) { ?>
            <li><a href="usuarios.php">Usuários</a></li>
        <?php } ?>
        <li><a href="logout.php">Sair do sistema</a></li>
    </ul>

    <center>
        <h2>INCLUIR OBRA</h2>

        <form name="formulario" method="post" action="inclui_obra.php">
            <table>
                <tr>
                    <td><label for="Descricao">Descrição da Obra</label></td>
                    <td><input type="text" id="Descricao" name="Descricao" maxlength="60" placeholder="Ex: Edifício Horizonte" required autofocus></td>
                </tr>
                <tr>
                    <td><label for="idEngenheiro">Engenheiro Responsável</label></td>
                    <td>
                        <select id="idEngenheiro" name="idEngenheiro" required>
                            <option value="">Selecione o Engenheiro...</option>
                            <?php
                            if ($conn) {
                                $resEngList = mysqli_query($conn, "SELECT idEngenheiro, dsNome, nrCREA FROM engenheiros ORDER BY dsNome ASC");
                                if ($resEngList) {
                                    while ($eng = mysqli_fetch_assoc($resEngList)) {
                                        echo "<option value='" . htmlspecialchars($eng['idEngenheiro']) . "'>" 
                                             . htmlspecialchars($eng['dsNome']) . " (CREA: " . htmlspecialchars($eng['nrCREA']) . ")</option>";
                                    }
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="dtInicio">Data Início</label></td>
                    <td><input type="date" id="dtInicio" name="dtInicio" required></td>
                </tr>
                <tr>
                    <td><label for="dtFim">Data Fim</label></td>
                    <td><input type="date" id="dtFim" name="dtFim"></td>
                </tr>
            </table>

            <div class="acoes">
                <button type="submit" class="btn-acao">Incluir</button>
            </div>
        </form>

        <a href="obras.php" class="btn-voltar">Voltar</a>
    </center>

</body>
</html>