<?php
include_once "sessao.php";
include_once "conexao.php";

$conn = @mysqli_connect($localhost, $user, $password, $banco);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Consulta de Obras</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
            padding-top: 100px;
        }

        ul.menu-topo {
            list-style-type: none;
            margin: 0;
            padding: 0 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #ffffff;
            border-bottom: 4px solid #e67e22;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            box-sizing: border-box;
            z-index: 1000;
        }

        ul.menu-topo li {
            display: inline-block;
        }

        ul.menu-topo li a {
            display: block;
            padding: 16px 20px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            font-size: 0.95rem;
            transition: all 0.2s ease;
        }

        ul.menu-topo li a:hover {
            background-color: #fdf2e9;
            color: #d35400;
        }

        ul.menu-topo li:last-child {
            margin-left: auto;
        }

        ul.menu-topo li a[href="logout.php"] {
            color: #c0392b;
        }

        ul.menu-topo li a[href="logout.php"]:hover {
            background-color: #c0392b;
            color: #ffffff;
        }

        h2 {
            color: #d35400;
            margin-top: 20px;
            font-size: 1.8rem;
        }

        .card-consulta {
            margin-top: 20px;
            background: #ffffff;
            padding: 25px;
            border-radius: 10px;
            border-top: 5px solid #e67e22;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            max-width: 1050px;
            width: 95%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background-color: #fdf2e9;
            color: #d35400;
            padding: 12px 15px;
            text-align: left;
            border-bottom: 2px solid #e2e8f0;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
            font-size: 0.95rem;
            color: #333;
        }

        tr:hover {
            background-color: #f8fafc;
        }

        td:first-child, th:first-child {
            text-align: center;
            width: 8%;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 18px;
            color: #888888;
            font-size: 0.88rem;
            text-decoration: underline;
            font-weight: bold;
            transition: color 0.2s ease;
        }

        .btn-voltar:hover {
            color: #555555;
        }
    </style>
</head>
<body>

    <ul class="menu-topo">
        <li><a href="funcoes.php">Funções</a></li>
        <li><a href="engenheiros.php">Engenheiros envolvidos</a></li>
        <li><a href="fase.php">Fase da obra</a></li>
        <li><a href="obras.php">Obras</a></li>
        <?php if (isset($_SESSION['flStatus']) && $_SESSION['flStatus'] == 1) { ?>
            <li><a href="usuarios.php">Usuários</a></li>
        <?php } ?>
        <li><a href="logout.php">Sair do sistema</a></li>
    </ul>

    <center>
        <h2>CONSULTA DE OBRAS</h2>

        <div class="card-consulta">
            <?php
            if ($conn) {
                $sql = "SELECT o.idObra, o.Descricao, o.dtInicio, o.dtFim, o.idEngenheiro, o.nrCrea, o.dtDdmissaoEngenheiro, e.dsNome
                        FROM obras o
                        LEFT JOIN engenheiros e ON o.idEngenheiro = e.idEngenheiro
                        ORDER BY o.idObra ASC";
                $result = mysqli_query($conn, $sql);

                if ($result) {
                    if (mysqli_num_rows($result) > 0) {
            ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Código</th>
                                    <th>Descrição</th>
                                    <th>Início</th>
                                    <th>Fim</th>
                                    <th>Engenheiro</th>
                                    <th>CREA</th>
                                    <th>Admissão Eng.</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($result)) { 
                                    $dtIniFmt = !empty($row['dtInicio']) ? date('d/m/Y', strtotime($row['dtInicio'])) : '-';
                                    $dtFimFmt = !empty($row['dtFim']) ? date('d/m/Y', strtotime($row['dtFim'])) : '<span style="color:#94a3b8;font-style:italic;">Em andamento</span>';
                                    $dtAdmFmt = !empty($row['dtDdmissaoEngenheiro']) ? date('d/m/Y', strtotime($row['dtDdmissaoEngenheiro'])) : '-';
                                    $nomeEng = !empty($row['dsNome']) ? htmlspecialchars($row['dsNome']) : 'ID #' . htmlspecialchars((string)$row['idEngenheiro']);
                                ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['idObra']); ?></td>
                                        <td><strong><?php echo htmlspecialchars($row['Descricao']); ?></strong></td>
                                        <td><?php echo $dtIniFmt; ?></td>
                                        <td><?php echo $dtFimFmt; ?></td>
                                        <td><?php echo $nomeEng; ?></td>
                                        <td><?php echo htmlspecialchars((string)$row['nrCrea']); ?></td>
                                        <td><?php echo $dtAdmFmt; ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
            <?php 
                    } else {
                        echo "<p style='color: #7f8c8d; margin: 10px 0;'>Nenhuma obra cadastrada.</p>";
                    }
                } else {
                    echo "<p style='color: red; margin: 10px 0;'>Erro na consulta SQL: " . htmlspecialchars(mysqli_error($conn)) . "</p>";
                }
                mysqli_close($conn);
            } else {
                echo "<p style='color: red; margin: 10px 0;'>Erro ao conectar com o banco de dados: " . htmlspecialchars(mysqli_connect_error()) . "</p>";
            }
            ?>
        </div>

        <a href="obras.php" class="btn-voltar">Voltar</a>
    </center>

</body>
</html>