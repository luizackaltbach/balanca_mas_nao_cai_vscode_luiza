<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['usuario'])) {
    header("Location: index.html");
    exit();
}

function verificarAdmin() {
    if (!isset($_SESSION['idUsuario']) || $_SESSION['idUsuario'] != 2) {
        echo "<script>
                alert('Acesso negado! Esta área é restrita a administradores.');
                window.location.href = 'mostra.php';
              </script>";
        exit();
    }
}
?>