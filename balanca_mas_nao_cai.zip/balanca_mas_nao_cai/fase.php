<?php
include_once "conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dsFase = $_POST['dsFase'];

    $sql = "INSERT INTO fases (dsFase) VALUES ('$dsFase')";

    if (mysqli_query($conn, $sql)) {
        $mensagem = "<p style='color: green; font-weight: bold; margin-top: 15px;'>Fase incluída com sucesso!</p>";
    } else {
        $mensagem = "<p style='color: red; font-weight: bold; margin-top: 15px;'>Erro ao incluir: " . mysqli_error($conn) . "</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle de Obras - Fases</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
            padding-top: 100px;
        }

        ul.menu-topo {
            list-style-type: none;
            margin: 0;
            padding: 0 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #ffffff;
            border-bottom: 4px solid #e67e22;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            box-sizing: border-box;
            z-index: 1000;
        }

        ul.menu-topo li {
            display: inline-block;
        }

        ul.menu-topo li a {
            display: block;
            padding: 16px 20px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            font-size: 0.95rem;
            transition: all 0.2s ease;
        }

        ul.menu-topo li a:hover {
            background-color: #fdf2e9;
            color: #d35400;
        }

        ul.menu-topo li:last-child {
            margin-left: auto;
        }

        ul.menu-topo li a[href="logout.php"] {
            color: #c0392b;
        }

        ul.menu-topo li a[href="logout.php"]:hover {
            background-color: #c0392b;
            color: #ffffff;
        }

        h2 {
            color: #d35400;
            margin-top: 20px;
            font-size: 1.8rem;
        }

        form {
            margin-top: 20px;
            background: #ffffff;
            padding: 25px;
            border-radius: 10px;
            border-top: 5px solid #e67e22;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            max-width: 450px;
            width: 90%;
        }

        .acoes-empilhadas {
            margin-top: 10px;
            display: flex;
            flex-direction: column; 
            gap: 12px;
            width: 100%;
        }

        .btn-opcao {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 50px;
            background-color: #ffffff;
            color: #e67e22;
            border: 2px solid #e67e22;
            border-radius: 8px;
            font-weight: bold;
            font-size: 1rem;
            text-decoration: none;
            cursor: pointer;
            box-sizing: border-box;
            transition: all 0.2s ease;
        }

        .btn-opcao:hover {
            background-color: #e67e22;
            color: #ffffff;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(230, 126, 34, 0.25);
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 18px;
            color: #888888;
            font-size: 0.88rem;
            text-decoration: underline;
            font-weight: bold;
            transition: color 0.2s ease;
        }

        .btn-voltar:hover {
            color: #555555;
        }
    </style>
</head>
<body>

    <ul class="menu-topo">
    <li><a href="funcoes.php">Funções</a></li>
    <li><a href="engenheiros.php">Engenheiros envolvidos</a></li>
    <li><a href="fase.php">Fase da obra</a></li>
    <li><a href="obras.php">Obras</a></li>
    <?php if (isset($_SESSION['flStatus']) && $_SESSION['flStatus'] == 1) { ?>
        <li><a href="usuarios.php">Usuários</a></li>
    <?php } ?>
    <li><a href="logout.php">Sair do sistema</a></li>
</ul>

    <center>
        <h2>GERENCIAMENTO DE FASE DA OBRA</h2>

        <?php 
        if (isset($mensagem)) {
            echo $mensagem;
        }
        ?>

        <form method="POST" action="">
            <div class="acoes-empilhadas">
                <a href="inclui_fase.php" class="btn-opcao">Incluir</a>
                <a href="consulta_fase.php" class="btn-opcao">Consultar</a>
                <a href="altera_fase.php" class="btn-opcao">Alterar</a>
                <a href="exclui_fase.php" class="btn-opcao">Excluir</a>
            </div>
        </form>

        <a href="mostra.php" class="btn-voltar">Voltar</a>
    </center>

</body>
</html>