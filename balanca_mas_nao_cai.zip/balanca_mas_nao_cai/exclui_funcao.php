<?php
include_once "sessao.php";
include_once "conexao.php";

$conn = @mysqli_connect($localhost, $user, $password, $banco);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $idFuncao = $_POST['id'];

    if (!empty($idFuncao) && $conn) {
        $idTratado = mysqli_real_escape_string($conn, $idFuncao);
        $sql = "DELETE FROM funcoes WHERE idFuncao = '$idTratado'";

        if (mysqli_query($conn, $sql)) {
            echo "<script>
                    alert('Função excluída com sucesso!');
                    window.location.href = 'exclui_funcao.php';
                  </script>";
            exit;
        } else {
            $erro = mysqli_error($conn);
            echo "<script>
                    alert('Erro ao excluir: " . addslashes($erro) . "');
                    window.location.href = 'exclui_funcao.php';
                  </script>";
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Excluir Função</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
            padding-top: 100px;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #ffffff;
            border-bottom: 4px solid #e67e22;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            box-sizing: border-box;
            z-index: 1000;
        }

        li {
            display: inline-block;
        }

        li a {
            display: block;
            padding: 16px 20px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            font-size: 0.95rem;
            transition: all 0.2s ease;
        }

        li a:hover {
            background-color: #fdf2e9;
            color: #d35400;
        }

        li:last-child {
            margin-left: auto;
        }

        li a[href="logout.php"] {
            color: #c0392b;
        }

        li a[href="logout.php"]:hover {
            background-color: #c0392b;
            color: #ffffff;
        }

        h2 {
            color: #d35400;
            margin-top: 20px;
            font-size: 1.8rem;
        }

        .card-consulta {
            margin-top: 20px;
            background: #ffffff;
            padding: 25px;
            border-radius: 10px;
            border-top: 5px solid #e67e22;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            max-width: 650px;
            width: 90%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background-color: #fdf2e9;
            color: #d35400;
            padding: 12px 15px;
            text-align: left;
            border-bottom: 2px solid #e2e8f0;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
            font-size: 0.95rem;
            color: #333;
        }

        tr:hover {
            background-color: #f8fafc;
        }

        td:first-child, th:first-child {
            text-align: center;
            width: 20%;
        }

        td:last-child, th:last-child {
            text-align: right;
            width: 25%;
        }

        .btn-delete {
            background-color: #c0392b;
            color: #ffffff;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.85rem;
            display: inline-block;
            transition: background-color 0.2s ease;
        }

        .btn-delete:hover {
            background-color: #962d22;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 18px;
            color: #888888;
            font-size: 0.88rem;
            text-decoration: underline;
            font-weight: bold;
            transition: color 0.2s ease;
        }

        .btn-voltar:hover {
            color: #555555;
        }
    </style>
</head>
<body>

    <ul>
        <li><a href="funcoes.php">Funções</a></li>
        <li><a href="engenheiros.php">Engenheiros envolvidos</a></li>
        <li><a href="fase.php">Fase da obra</a></li>
        <li><a href="obras.php">Obras</a></li>
        <li><a href="logout.php">Sair do sistema</a></li>
    </ul>

    <center>
        <h2>EXCLUIR FUNÇÃO</h2>

        <div class="card-consulta">
            <?php
            if ($conn) {
                $sql = "SELECT idFuncao, dsFuncao FROM funcoes";
                $result = mysqli_query($conn, $sql);

                if ($result && mysqli_num_rows($result) > 0) {
            ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Descrição da Função</th>
                                <th>Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row[0]); ?></td>
                                    <td><?php echo htmlspecialchars($row[1]); ?></td>
                                    <td>
                                        <form method="post" action="exclui_funcao.php" style="margin: 0;" onsubmit="return confirm('Tem certeza que deseja excluir esta função?');">
                                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($row[0]); ?>">
                                            <button type="submit" class="btn-delete">Excluir</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
            <?php 
                } else {
                    echo "<p style='color: #7f8c8d; margin: 10px 0;'>Nenhuma função cadastrada para exclusão.</p>";
                }
                mysqli_close($conn);
            } else {
                echo "<p style='color: red; margin: 10px 0;'>Erro ao conectar com o banco de dados.</p>";
            }
            ?>
        </div>

        <a href="funcoes.php" class="btn-voltar">Voltar</a>
    </center>

</body>
</html>