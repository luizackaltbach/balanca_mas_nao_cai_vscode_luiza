<?php
include_once "sessao.php";
include_once "conexao.php";

$conn = @mysqli_connect($localhost, $user, $password, $banco);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idObra = isset($_POST['idObra']) ? $_POST['idObra'] : '';
    $idEngenheiro = isset($_POST['idEngenheiro']) ? $_POST['idEngenheiro'] : '';
    $idFuncao = isset($_POST['idFuncao']) ? $_POST['idFuncao'] : '';
    $dtInicio = isset($_POST['dtInicio']) ? $_POST['dtInicio'] : '';
    $dtFim = isset($_POST['dtFim']) ? $_POST['dtFim'] : '';

    if (!$conn) {
        echo "<script>alert('Erro ao conectar com o banco de dados.');</script>";
    } elseif (!empty($idObra) && !empty($idEngenheiro) && !empty($idFuncao) && !empty($dtInicio)) {
        $idObraTratado = mysqli_real_escape_string($conn, $idObra);
        $idEngTratado = mysqli_real_escape_string($conn, $idEngenheiro);
        $idFuncTratado = mysqli_real_escape_string($conn, $idFuncao);
        $dtInicioTratada = mysqli_real_escape_string($conn, $dtInicio);
        $dtFimTratada = !empty($dtFim) ? "'" . mysqli_real_escape_string($conn, $dtFim) . "'" : "NULL";

        $sql = "INSERT INTO engenheiros_obras (idEngenheiro, idObra, dtInicio, dtFim, idFuncao) 
                VALUES ('$idEngTratado', '$idObraTratado', '$dtInicioTratada', $dtFimTratada, '$idFuncTratado')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>
                    alert('Engenheiro vinculado à obra com sucesso!');
                    window.location.href = 'engenheiros.php';
                  </script>";
            exit;
        } else {
            $erro = mysqli_error($conn);
            echo "<script>
                    alert('Erro ao vincular: " . addslashes($erro) . "');
                  </script>";
        }
    } else {
        echo "<script>alert('Preencha todos os campos obrigatórios!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Vincular engenheiro à obra</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
            padding-top: 100px;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #ffffff;
            border-bottom: 4px solid #e67e22;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            box-sizing: border-box;
            z-index: 1000;
        }

        li {
            display: inline-block;
        }

        li a {
            display: block;
            padding: 16px 20px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            font-size: 0.95rem;
            transition: all 0.2s ease;
        }

        li a:hover {
            background-color: #fdf2e9;
            color: #d35400;
        }

        li:last-child {
            margin-left: auto;
        }

        li a[href="logout.php"] {
            color: #c0392b;
        }

        li a[href="logout.php"]:hover {
            background-color: #c0392b;
            color: #ffffff;
        }

        h2 {
            color: #d35400;
            margin-top: 20px;
            font-size: 1.8rem;
        }

        form {
            margin-top: 20px;
            background: #ffffff;
            padding: 25px;
            border-radius: 10px;
            border-top: 5px solid #e67e22;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            max-width: 500px;
            width: 90%;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
        }

        td {
            padding: 4px 0;
            vertical-align: middle;
        }

        td:first-child {
            text-align: right;
            padding-right: 12px;
            width: 35%;
        }

        label {
            font-size: 0.9rem;
            font-weight: bold;
            color: #555555;
        }

        select, input[type="date"] {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 0.9rem;
            box-sizing: border-box;
            background-color: #fff;
        }

        select:focus, input[type="date"]:focus {
            border-color: #e67e22;
            outline: none;
        }

        .acoes {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-acao {
            background-color: #e67e22;
            color: #ffffff;
            border: none;
            padding: 10px 16px;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            display: inline-block;
            transition: background-color 0.2s ease;
        }

        .btn-acao:hover {
            background-color: #d35400;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 18px;
            color: #888888;
            font-size: 0.88rem;
            text-decoration: underline;
            font-weight: bold;
            transition: color 0.2s ease;
        }

        .btn-voltar:hover {
            color: #555555;
        }
    </style>
</head>
<body>

    <ul>
        <li><a href="funcoes.php">Funções</a></li>
        <li><a href="engenheiros.php">Engenheiros envolvidos</a></li>
        <li><a href="fase.php">Fase da obra</a></li>
        <li><a href="obras.php">Obras</a></li>
        <li><a href="logout.php">Sair do sistema</a></li>
    </ul>

    <center>
        <h2>VINCULAR ENGENHEIRO À OBRA</h2>

        <form name="formulario" method="post" action="">
            <table>
                <tr>
                    <td><label for="idObra">Obra</label></td>
                    <td>
                        <select id="idObra" name="idObra" required>
                            <option value="">Selecione a Obra...</option>
                            <?php
                            if ($conn) {
                                $resObras = mysqli_query($conn, "SELECT * FROM obras");
                                if ($resObras) {
                                    if (mysqli_num_rows($resObras) > 0) {
                                        while ($ob = mysqli_fetch_array($resObras, MYSQLI_NUM)) {
                                            echo "<option value='".$ob[0]."'>".htmlspecialchars($ob[1])."</option>";
                                        }
                                    } else {
                                        echo "<option value=''>Nenhuma obra cadastrada no banco</option>";
                                    }
                                } else {
                                    echo "<option value=''>ERRO: " . mysqli_error($conn) . "</option>";
                                }
                            } else {
                                echo "<option value=''>ERRO: Sem conexão com o banco</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="idEngenheiro">Engenheiro</label></td>
                    <td>
                        <select id="idEngenheiro" name="idEngenheiro" required>
                            <option value="">Selecione o Engenheiro...</option>
                            <?php
                            if ($conn) {
                                $resEng = mysqli_query($conn, "SELECT * FROM engenheiros");
                                if ($resEng) {
                                    if (mysqli_num_rows($resEng) > 0) {
                                        while ($eng = mysqli_fetch_array($resEng, MYSQLI_NUM)) {
                                            echo "<option value='".$eng[0]."'>".htmlspecialchars($eng[1])."</option>";
                                        }
                                    } else {
                                        echo "<option value=''>Nenhum engenheiro cadastrado no banco</option>";
                                    }
                                } else {
                                    echo "<option value=''>ERRO: " . mysqli_error($conn) . "</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="idFuncao">Função</label></td>
                    <td>
                        <select id="idFuncao" name="idFuncao" required>
                            <option value="">Selecione a Função...</option>
                            <?php
                            if ($conn) {
                                $resFunc = mysqli_query($conn, "SELECT * FROM funcoes");
                                if ($resFunc) {
                                    if (mysqli_num_rows($resFunc) > 0) {
                                        while ($func = mysqli_fetch_array($resFunc, MYSQLI_NUM)) {
                                            echo "<option value='".$func[0]."'>".htmlspecialchars($func[1])."</option>";
                                        }
                                    } else {
                                        echo "<option value=''>Nenhuma função cadastrada no banco</option>";
                                    }
                                } else {
                                    echo "<option value=''>ERRO: " . mysqli_error($conn) . "</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="dtInicio">Data Início</label></td>
                    <td><input type="date" id="dtInicio" name="dtInicio" required></td>
                </tr>
                <tr>
                    <td><label for="dtFim">Data Fim</label></td>
                    <td><input type="date" id="dtFim" name="dtFim"></td>
                </tr>
            </table>

            <div class="acoes">
                <button type="submit" class="btn-acao">Salvar</button>
            </div>
        </form>

        <a href="engenheiros.php" class="btn-voltar">Voltar</a>
    </center>

    <?php if ($conn) { mysqli_close($conn); } ?>
</body>
</html>