<?php
include_once "sessao.php";
include_once "conexao.php";

$conn = @mysqli_connect($localhost, $user, $password, $banco);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Consulta de Engenheiros</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
            padding-top: 100px;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #ffffff;
            border-bottom: 4px solid #e67e22;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            box-sizing: border-box;
            z-index: 1000;
        }

        li {
            display: inline-block;
        }

        li a {
            display: block;
            padding: 16px 20px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            font-size: 0.95rem;
            transition: all 0.2s ease;
        }

        li a:hover {
            background-color: #fdf2e9;
            color: #d35400;
        }

        li:last-child {
            margin-left: auto;
        }

        li a[href="logout.php"] {
            color: #c0392b;
        }

        li a[href="logout.php"]:hover {
            background-color: #c0392b;
            color: #ffffff;
        }

        h2 {
            color: #d35400;
            margin-top: 20px;
            font-size: 1.8rem;
        }

        .card-consulta {
            margin-top: 20px;
            background: #ffffff;
            padding: 25px;
            border-radius: 10px;
            border-top: 5px solid #e67e22;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            max-width: 750px;
            width: 90%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background-color: #fdf2e9;
            color: #d35400;
            padding: 12px 15px;
            text-align: left;
            border-bottom: 2px solid #e2e8f0;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
            font-size: 0.95rem;
            color: #333;
        }

        tr:hover {
            background-color: #f8fafc;
        }

        td:first-child, th:first-child {
            text-align: center;
            width: 15%;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 18px;
            color: #888888;
            font-size: 0.88rem;
            text-decoration: underline;
            font-weight: bold;
            transition: color 0.2s ease;
        }

        .btn-voltar:hover {
            color: #555555;
        }
    </style>
</head>
<body>

    <ul>
        <li><a href="funcoes.php">Funções</a></li>
        <li><a href="engenheiros.php">Engenheiros envolvidos</a></li>
        <li><a href="fase.php">Fase da obra</a></li>
        <li><a href="obras.php">Obras</a></li>
        <li><a href="logout.php">Sair do sistema</a></li>
    </ul>

    <center>
        <h2>CONSULTA DE ENGENHEIROS</h2>

        <div class="card-consulta">
            <?php
            if ($conn) {
                $sql = "SELECT idEngenheiro, dsNome, nrCREA, dtAdmissao FROM engenheiros";
                $result = mysqli_query($conn, $sql);

                if ($result && mysqli_num_rows($result) > 0) {
            ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Nome</th>
                                <th>CREA</th>
                                <th>Admissão</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row[0]); ?></td>
                                    <td><?php echo htmlspecialchars($row[1]); ?></td>
                                    <td><?php echo htmlspecialchars($row[2]); ?></td>
                                    <td><?php echo !empty($row[3]) ? date('d/m/Y', strtotime($row[3])) : '-'; ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
            <?php 
                } else {
                    echo "<p style='color: #7f8c8d; margin: 10px 0;'>Nenhum engenheiro cadastrado.</p>";
                }
                mysqli_close($conn);
            } else {
                echo "<p style='color: red; margin: 10px 0;'>Erro ao conectar com o banco de dados.</p>";
            }
            ?>
        </div>

        <a href="engenheiros.php" class="btn-voltar">Voltar</a>
    </center>

</body>
</html>