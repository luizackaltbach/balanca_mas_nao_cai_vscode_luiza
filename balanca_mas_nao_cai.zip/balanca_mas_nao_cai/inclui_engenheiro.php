<?php
include_once "sessao.php";
include_once "conexao.php";

$conn = @mysqli_connect($localhost, $user, $password, $banco);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dsNome = isset($_POST['dsNome']) ? trim($_POST['dsNome']) : '';
    $nrCREA = isset($_POST['nrCREA']) ? trim($_POST['nrCREA']) : '';
    $dtAdmissao = isset($_POST['dtAdmissao']) ? trim($_POST['dtAdmissao']) : '';

    if (!empty($dsNome) && $conn) {
        $nomeTratado = mysqli_real_escape_string($conn, $dsNome);
        $creaTratado = mysqli_real_escape_string($conn, $nrCREA);
        $admissaoTratada = mysqli_real_escape_string($conn, $dtAdmissao);

        $sql = "INSERT INTO engenheiros (dsNome, nrCREA, dtAdmissao) VALUES ('$nomeTratado', '$creaTratado', '$admissaoTratada')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>
                    alert('Engenheiro cadastrado com sucesso!');
                    window.location.href = 'engenheiros.php';
                  </script>";
            exit;
        } else {
            $erro = mysqli_error($conn);
            echo "<script>
                    alert('Erro ao incluir: " . addslashes($erro) . "');
                    window.location.href = 'engenheiros.php';
                  </script>";
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Inclusão de Engenheiro</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
            padding-top: 100px;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #ffffff;
            border-bottom: 4px solid #e67e22;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            box-sizing: border-box;
            z-index: 1000;
        }

        li {
            display: inline-block;
        }

        li a {
            display: block;
            padding: 16px 20px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            font-size: 0.95rem;
            transition: all 0.2s ease;
        }

        li a:hover {
            background-color: #fdf2e9;
            color: #d35400;
        }

        li:last-child {
            margin-left: auto;
        }

        li a[href="logout.php"] {
            color: #c0392b;
        }

        li a[href="logout.php"]:hover {
            background-color: #c0392b;
            color: #ffffff;
        }

        h2 {
            color: #d35400;
            margin-top: 20px;
            font-size: 1.8rem;
        }

        form {
            margin-top: 20px;
            background: #ffffff;
            padding: 25px;
            border-radius: 10px;
            border-top: 5px solid #e67e22;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            max-width: 450px;
            width: 90%;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
        }

        td {
            padding: 4px 0;
            vertical-align: middle;
        }

        td:first-child {
            text-align: right;
            padding-right: 12px;
            width: 35%;
        }

        label {
            font-size: 0.9rem;
            font-weight: bold;
            color: #555555;
        }

        input[type="text"], input[type="date"] {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 0.9rem;
            box-sizing: border-box;
        }

        input[type="text"]:focus, input[type="date"]:focus {
            border-color: #e67e22;
            outline: none;
        }

        .acoes {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-acao {
            background-color: #e67e22;
            color: #ffffff;
            border: none;
            padding: 10px 16px;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            display: inline-block;
            transition: background-color 0.2s ease;
        }

        .btn-acao:hover {
            background-color: #d35400;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 18px;
            color: #888888;
            font-size: 0.88rem;
            text-decoration: underline;
            font-weight: bold;
            transition: color 0.2s ease;
        }

        .btn-voltar:hover {
            color: #555555;
        }
    </style>
</head>
<body>

    <ul>
        <li><a href="funcoes.php">Funções</a></li>
        <li><a href="engenheiros.php">Engenheiros envolvidos</a></li>
        <li><a href="fase.php">Fase da obra</a></li>
        <li><a href="obras.php">Obras</a></li>
        <li><a href="logout.php">Sair do sistema</a></li>
    </ul>

    <center>
        <h2>INCLUIR ENGENHEIRO</h2>

        <form name="formulario" method="post" action="inclui_engenheiro.php">
            <table>
                <tr>
                    <td><label for="dsNome">Nome</label></td>
                    <td><input type="text" id="dsNome" name="dsNome" maxlength="60" placeholder="Ex: Carlos Silva" required autofocus></td>
                </tr>
                <tr>
                    <td><label for="nrCREA">CREA</label></td>
                    <td><input type="text" id="nrCREA" name="nrCREA" maxlength="20" placeholder="Ex: 123456/D" required></td>
                </tr>
                <tr>
                    <td><label for="dtAdmissao">Admissão</label></td>
                    <td><input type="date" id="dtAdmissao" name="dtAdmissao" required></td>
                </tr>
            </table>

            <div class="acoes">
                <button type="submit" class="btn-acao">Incluir</button>
            </div>
        </form>

        <a href="engenheiros.php" class="btn-voltar">Voltar</a>
    </center>

</body>
</html>