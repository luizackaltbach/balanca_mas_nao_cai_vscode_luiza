<?php
include_once "sessao.php";
verificarAdmin();
include_once "conexao.php";

$conn = @mysqli_connect($localhost, $user, $password, $banco);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Balança mas não cai - Alterar Usuário</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; color: #333; margin: 0; padding-top: 100px; }
        ul { list-style-type: none; margin: 0; padding: 0 20px; position: fixed; top: 0; left: 0; width: 100%; background: #ffffff; border-bottom: 4px solid #e67e22; box-shadow: 0 2px 10px rgba(0,0,0,0.1); display: flex; align-items: center; box-sizing: border-box; z-index: 1000; }
        li { display: inline-block; }
        li a { display: block; padding: 16px 20px; color: #333; text-decoration: none; font-weight: bold; font-size: 0.95rem; }
        li a:hover { background-color: #fdf2e9; color: #d35400; }
        li:last-child { margin-left: auto; }
        li a[href="logout.php"] { color: #c0392b; }
        h2 { color: #d35400; margin-top: 20px; font-size: 1.8rem; }
        .card-consulta { margin-top: 20px; background: #ffffff; padding: 25px; border-radius: 10px; border-top: 5px solid #e67e22; box-shadow: 0 4px 12px rgba(0,0,0,0.08); max-width: 750px; width: 90%; }
        table { width: 100%; border-collapse: collapse; }
        th { background-color: #fdf2e9; color: #d35400; padding: 12px 15px; text-align: left; border-bottom: 2px solid #e2e8f0; font-size: 0.85rem; text-transform: uppercase; }
        td { padding: 12px 15px; border-bottom: 1px solid #e2e8f0; font-size: 0.95rem; }
        .btn-acao { background-color: #e67e22; color: #ffffff; border: none; padding: 6px 12px; border-radius: 6px; font-weight: bold; cursor: pointer; }
        .btn-voltar { display: inline-block; margin-top: 18px; color: #888; font-size: 0.88rem; text-decoration: underline; font-weight: bold; }
    </style>
</head>
<body>
    <ul>
        <li><a href="funcoes.php">Funções</a></li>
        <li><a href="engenheiros.php">Engenheiros envolvidos</a></li>
        <li><a href="fase.php">Fase da obra</a></li>
        <li><a href="obras.php">Obras</a></li>
        <li><a href="logout.php">Sair do sistema</a></li>
    </ul>

    <center>
        <h2>ALTERAR USUÁRIO</h2>

        <div class="card-consulta">
            <?php
            if ($conn) {
                $sql = "SELECT idUsuario, Nome, Email FROM usuarios";
                $result = mysqli_query($conn, $sql);

                if ($result && mysqli_num_rows($result) > 0) {
            ?>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['idUsuario']); ?></td>
                                    <td><?php echo htmlspecialchars($row['Nome']); ?></td>
                                    <td><?php echo htmlspecialchars($row['Email']); ?></td>
                                    <td>
                                        <form method="post" action="muda_usuario.php" style="margin:0;">
                                            <input type="hidden" name="id" value="<?php echo $row['idUsuario']; ?>">
                                            <button type="submit" class="btn-acao">Alterar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
            <?php 
                }
                mysqli_close($conn);
            }
            ?>
        </div>

        <a href="usuarios.php" class="btn-voltar">Voltar</a>
    </center>
</body>
</html>