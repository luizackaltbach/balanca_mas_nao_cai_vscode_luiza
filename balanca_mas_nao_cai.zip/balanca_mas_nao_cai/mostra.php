<?php
include_once "sessao.php";

$usuario = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : '';
$isAdmin = isset($_SESSION['idUsuario']) && $_SESSION['idUsuario'] == 2;


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Controle de obras</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        center {
            width: 100%;
            max-width: 700px;
            padding: 20px;
            box-sizing: border-box;
        }

        h2 {
            color: #d35400;
            margin-top: 0;
            margin-bottom: 35px;
            font-size: 2rem;
        }

        ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            width: 100%;
            box-sizing: border-box;
        }

        li {
            width: 100%;
        }

        li a {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 120px;
            background-color: #e67e22;
            color: #ffffff;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.15rem;
            text-align: center;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            box-sizing: border-box;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease;
        }

        li a:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(211, 84, 0, 0.25);
            background-color: #d35400;
        }

        li.logout-item {
            grid-column: span 2;
            margin-top: 10px;
        }

        li a[href="logout.php"] {
            height: auto;
            padding: 12px;
            background-color: transparent;
            color: #7f8c8d;
            border: 1px solid #dcdde1;
            box-shadow: none;
            font-size: 0.95rem;
            font-weight: normal;
        }

        li a[href="logout.php"]:hover {
            transform: none;
            background-color: #e2e3e9;
            color: #2c3e50;
            border-color: #bdc3c7;
            box-shadow: none;
        }
    </style>
</head>
<body>
    <center>
        <h2>Seja bem-vindo(a), <?php echo htmlspecialchars($usuario); ?></h2>

        <ul>
            <li><a href="funcoes.php">Funções</a></li>
            <li><a href="engenheiros.php">Engenheiros envolvidos</a></li>
            <li><a href="fase.php">Fase da obra</a></li>
            <li><a href="obras.php">Obras</a></li>
            
            <?php if ($isAdmin) { ?>
                <li><a href="usuarios.php">Gerenciar usuários</a></li>
            <?php } ?>

            <li class="logout-item"><a href="logout.php">Sair do sistema</a></li>
        </ul>
    </center>
</body>
</html>