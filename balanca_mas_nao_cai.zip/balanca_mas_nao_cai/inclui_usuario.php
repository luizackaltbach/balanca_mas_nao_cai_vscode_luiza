<?php
include_once "sessao.php";
verificarAdmin();
include_once "conexao.php";

$conn = @mysqli_connect($localhost, $user, $password, $banco);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = isset($_POST['Nome']) ? trim($_POST['Nome']) : '';
    $email = isset($_POST['Email']) ? trim($_POST['Email']) : '';
    $senha = isset($_POST['Senha']) ? trim($_POST['Senha']) : '';
    $flStatus = isset($_POST['flStatus']) ? intval($_POST['flStatus']) : 0;

    if (!empty($nome) && !empty($email) && !empty($senha) && $conn) {
        $nomeT = mysqli_real_escape_string($conn, $nome);
        $emailT = mysqli_real_escape_string($conn, $email);
        $senhaT = mysqli_real_escape_string($conn, $senha);

        $sql = "INSERT INTO usuarios (Nome, Email, Senha, flStatus) VALUES ('$nomeT', '$emailT', '$senhaT', '$flStatus')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>
                    alert('Usuário cadastrado com sucesso!');
                    window.location.href = 'usuarios.php';
                  </script>";
            exit;
        } else {
            $erro = mysqli_error($conn);
            echo "<script>
                    alert('Erro ao incluir: " . addslashes($erro) . "');
                    window.location.href = 'usuarios.php';
                  </script>";
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Balança mas não cai - Incluir Usuário</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; color: #333; margin: 0; padding-top: 100px; }
        ul { list-style-type: none; margin: 0; padding: 0 20px; position: fixed; top: 0; left: 0; width: 100%; background: #ffffff; border-bottom: 4px solid #e67e22; box-shadow: 0 2px 10px rgba(0,0,0,0.1); display: flex; align-items: center; box-sizing: border-box; z-index: 1000; }
        li { display: inline-block; }
        li a { display: block; padding: 16px 20px; color: #333; text-decoration: none; font-weight: bold; font-size: 0.95rem; }
        li a:hover { background-color: #fdf2e9; color: #d35400; }
        li:last-child { margin-left: auto; }
        li a[href="logout.php"] { color: #c0392b; }
        h2 { color: #d35400; margin-top: 20px; font-size: 1.8rem; }
        form { margin-top: 20px; background: #ffffff; padding: 25px; border-radius: 10px; border-top: 5px solid #e67e22; box-shadow: 0 4px 12px rgba(0,0,0,0.08); max-width: 480px; width: 90%; }
        table { width: 100%; border-collapse: separate; border-spacing: 0 12px; }
        td { padding: 4px 0; vertical-align: middle; }
        td:first-child { text-align: right; padding-right: 12px; width: 35%; }
        label { font-size: 0.9rem; font-weight: bold; color: #555; }
        input[type="text"], input[type="email"], input[type="password"], select { width: 100%; padding: 8px 10px; border: 1px solid #ccc; border-radius: 6px; font-size: 0.9rem; box-sizing: border-box; }
        .btn-acao { background-color: #e67e22; color: #fff; border: none; padding: 10px 16px; border-radius: 6px; font-weight: bold; cursor: pointer; }
        .btn-voltar { display: inline-block; margin-top: 18px; color: #888; font-size: 0.88rem; text-decoration: underline; font-weight: bold; }
    </style>
</head>
<body>
    <ul>
        <li><a href="funcoes.php">Funções</a></li>
        <li><a href="engenheiros.php">Engenheiros envolvidos</a></li>
        <li><a href="fase.php">Fase da obra</a></li>
        <li><a href="obras.php">Obras</a></li>
        <li><a href="logout.php">Sair do sistema</a></li>
    </ul>

    <center>
        <h2>INCLUIR USUÁRIO</h2>

        <form method="post" action="inclui_usuario.php">
            <table>
                <tr>
                    <td><label for="Nome">Nome</label></td>
                    <td><input type="text" id="Nome" name="Nome" required autofocus></td>
                </tr>
                <tr>
                    <td><label for="Email">E-mail</label></td>
                    <td><input type="email" id="Email" name="Email" required></td>
                </tr>
                <tr>
                    <td><label for="Senha">Senha</label></td>
                    <td><input type="password" id="Senha" name="Senha" required></td>
                </tr>
                <tr>
                    <td><label for="flStatus">Perfil</label></td>
                    <td>
                        <select id="flStatus" name="flStatus" required>
                            <option value="0">Usuário Comum</option>
                            <option value="1">Administrador</option>
                        </select>
                    </td>
                </tr>
            </table>

            <div style="margin-top: 20px;">
                <button type="submit" class="btn-acao">Salvar Usuário</button>
            </div>
        </form>

        <a href="usuarios.php" class="btn-voltar">Voltar</a>
    </center>
</body>
</html>