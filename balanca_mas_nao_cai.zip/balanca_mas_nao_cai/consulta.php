<?php include_once "sessao.php"; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Consulta de Fases da Obra</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }
        body {
            background-color: #f8fafc;
            min-height: 100vh;
        }
        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .navMarca {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            text-decoration: none;
        }
        .nav {
            list-style: none;
            display: flex;
            gap: 8px;
            align-items: center;
        }
        .nav-link {
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #475569;
            text-decoration: none;
            transition: all 0.2s ease;
        }
        .nav-link:hover {
            background-color: #f1f5f9;
            color: #1e293b;
        }
        .nav-link.logout {
            background-color: #fee2e2;
            color: #b91c1c;
        }
        .nav-link.logout:hover {
            background-color: #fecaca;
            color: #991b1b;
        }
        .container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }
        .card {
            background: #ffffff;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
            border: 1px solid #e2e8f0;
        }
        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }
        h1 {
            color: #1e293b;
            font-size: 22px;
            font-weight: 600;
        }
        .btn-back {
            display: inline-flex;
            align-items: center;
            padding: 8px 16px;
            background-color: #f1f5f9;
            color: #475569;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: 6px;
            transition: background 0.2s;
        }
        .btn-back:hover {
            background-color: #e2e8f0;
            color: #0f172a;
        }
        .table-container {
            width: 100%;
            overflow-x: auto;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }
        thead {
            background-color: #f8fafc;
        }
        th {
            padding: 12px 16px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #64748b;
            border-bottom: 1px solid #e2e8f0;
        }
        td {
            padding: 14px 16px;
            font-size: 14px;
            color: #334155;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
        }
        tbody tr:last-child td {
            border-bottom: none;
        }
        tbody tr:hover {
            background-color: #f8fafc;
        }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 500;
            color: #2563eb;
            background-color: #eff6ff;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="dashboard.php" class="navMarca">Balança Mas Não Cai</a>
        <ul class="nav">
            <li><a href="mostra.php" class="nav-link">Home-page</a></li>
            <li class="nav-link">Obras</li>
            <li><a href="fases.php" class="nav-link">Fases da Obra</a></li>
            <li><a href="engenheiros.php" class="nav-link">Engenheiros</a></li>
            <li class="nav-link">Equipe/Obras</li>
            <li class="nav-link">Orçamentos</li>
            <li class="nav-link">Previsões</li>
            <li><a href="logout.php" class="nav-link logout">Sair</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="card">
            <div class="header-section">
                <h1>CONSULTA DE FASES DA OBRA</h1>
                <a href="fases.php" class="btn-back">← Voltar</a>
            </div>

            <?php
            $sql = "SELECT idFase, dsFase FROM fases";
            $result = mysqli_query($conn, $sql);
            ?>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Descrição da Fase</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) { ?>
                                <tr>
                                    <td><span class="badge">#<?php echo htmlspecialchars($row[0]); ?></span></td>
                                    <td><?php echo htmlspecialchars($row[1]); ?></td>
                                </tr>
                            <?php }
                        } else { ?>
                            <tr>
                                <td colspan="2" style="text-align: center; color: #94a3b8; padding: 24px;">
                                    Nenhuma fase cadastrada.
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php mysqli_close($conn); ?>
</body>
</html>
