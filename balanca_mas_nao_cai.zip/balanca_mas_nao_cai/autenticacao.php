<?php
session_start();

try {
    $usuarioInput = isset($_POST['usuario']) ? $_POST['usuario'] : '';
    $senhaInput = isset($_POST['Senha']) ? $_POST['Senha'] : '';

    include_once "conexao.php";

    $conn = mysqli_connect($localhost, $user, $password, $banco);

    if (!$conn) {
        header('Location: index.html');
        exit();
    }

    $usuarioEscaped = mysqli_real_escape_string($conn, $usuarioInput);
    $senhaEscaped = mysqli_real_escape_string($conn, $senhaInput);

    $sql = "SELECT * FROM usuarios WHERE Email='$usuarioEscaped' AND Senha='$senhaEscaped'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        $_SESSION['usuario'] = $row["Nome"];
        $_SESSION['dsEmail'] = $row["Email"];
        $_SESSION['senha'] = $row["Senha"];

        header('Location: mostra.php');
        exit();
    } else {
        header('Location: index.html');
        exit();
    }
} catch (Exception $e) {
    header('Location: index.html');
    exit();
}
?>